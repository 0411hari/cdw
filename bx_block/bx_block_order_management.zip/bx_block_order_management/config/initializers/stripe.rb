require "stripe"
Rails.configuration.stripe = {
  publishable_key: "pk_test_51KNwalSBe5Qg0mjEsKEPdxnMTBu9OmqAJnrmImp3v6Nsd7ECTj9I5eCXy2mSTDrN3yT3Ei6pBo0MQOBBvzCYpgsI00FCnmdnO2",
  secret_key:      "sk_test_51KNwalSBe5Qg0mjEFia2fIBZwdWpLFXpkID6JVf4RL1LRt94RZHGiDquBLQFpsbis6Hs5iupwJCT87DWwYaelJ3p00EHWIqzfr"
}
