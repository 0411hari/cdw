module BxBlockInvoiceBilling
    class ChargedItemsJob < ApplicationJob
      queue_as :default
      
    end
  end