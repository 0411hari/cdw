module BxBlockOrderManagement
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
