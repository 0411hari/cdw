require 'swagger_helper'

RSpec.describe 'bx_block_order_management', :jwt do
  let(:headers) { {:token => token} }

  let(:json)   { JSON response.body }
  let(:data)   { json['data'] }
  let(:token)  { jwt }
  let(:attributes) { data['attributes']}
  let(:errors) { json['errors'] }
  let(:error)  { errors.first }

  let(:account) { create :email_account }
  let(:id)      { account.id }
  let(:token) { BuilderJsonWebToken.encode(account.id, 1.day.from_now, token_type: 'login') }
  let!(:address) { FactoryBot.create(:delivery_address, account_id: account.id) }
  let(:address_params) do
    {
      "name" => address.name,
      "flat_no" => address.flat_no,
      "zip_code" => address.zip_code,
      "phone_number" => address.phone_number,
      "latitude" => address.latitude,
      "longitude" => address.longitude,
      "residential" => address.residential,
      "city" => address.city,
      "state_code" => address.state_code,
      "country_code" => address.country_code,
      "state" => address.state,
      "address_line_2" => address.address_line_2,
      "address_type" => address.address_type,
      "landmark" => address.landmark,
      "is_default" => address.is_default,
      "address_for" => address.address_for,
      "address" => 'Address details'
    }
  end

  let(:update_params) do
    {
      "address" => address.address
    }
  end

  path '/order_management/addresses/' do
    post 'Create Address ' do
      tags 'Address'
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      parameter name: :params, in: :body, schema: {
        type: :object,
        properties: {
          name: { type: :string },
                flat_no: { type: :string },
                address: { type: :string },
                address_type: { type: :string },
                address_line_2: { type: :string },
                zip_code: { type: :string },
                phone_number: { type: :string },
                address_for: { type: :string },
                city: { type: :string },
                state: { type: :string },
                landmark: { type: :string },
                residential: { type: :boolean },
                is_default: { type: :boolean },
                deleted_at: { type: :datetime },
                longitude: { type: :float },
                latitude: { type: :float }

        }
      }

      let(:params) { address_params }


      response '200', :success do
        schema type: :object,
                properties: {
                  data: {
                    id: { type: :integer },
                    type: { type: :string },
                    attributes: {
                      type: :object,
                      properties:{
                        id: { type: :integer },
                        name: { type: :string },
                        flat_no: { type: :string },
                        address: { type: :string },
                        address_type: { type: :string },
                        address_line_2: { type: :string },
                        zip_code: { type: :string },
                        phone_number: { type: :string },
                        address_for: { type: :string },
                        city: { type: :string },
                        state: { type: :string },
                        landmark: { type: :string },
                        residential: { type: :boolean },
                        is_default: { type: :boolean },
                        deleted_at: { type: :datetime },
                        longitude: { type: :float },
                        latitude: { type: :float },
                        created_at: { type: :datetime },
                        updated_at: { type: :datetime },
                        account:{
                          type: :object,
                          properties:{
                            activated: { type: :boolean },
                            country_code: { type: :string },
                            email: { type: :string },
                            first_name: { type: :string },
                            full_phone_number: { type: :string },
                            last_name: { type: :string },
                            phone_number: { type: :string },
                            type: { type: :string },
                            platform: { type: :string },
                            user_type: { type: :string },
                            status: { type: :string },
                            suspend_until: { type: :string },
                            user_name: { type: :string },
                            created_at: { type: :date },
                            updated_at: { type: :date },
                            device_id: { type: :string },
                            unique_auth_id: { type: :string }
                          }
                        }
                      }

                    }
                  }
                }

        before do |example|
          submit_request(example.metadata)
        end

        it 'Should have status 200' do
          expect(response.status).to eq 200
        end

        it 'Should have same response Account Id' do
          json_response = JSON.parse(response.body)
          expect(json_response["data"]["attributes"]["account"]["id"]).to eq account.id
        end
      end
      response '400', :unauthorized do
        let(:token)  { '' }

        run_test!
      end

      response '401', :unauthorized do
        let(:token)  { jwt_expired }

        run_test!
      end

    end

    get 'List of Addresses  ' do
      tags 'Addresses '
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      let!(:address) {FactoryBot.create(:delivery_address, account_id: account.id)}

      response '200', :success do
        schema type: :object,
          properties: {
            data: {
              id: { type: :integer },
              type: { type: :string },
              attributes: {
                type: :object,
                properties:{
                  id: { type: :integer },
                  name: { type: :string },
                  flat_no: { type: :string },
                  address: { type: :string },
                  address_type: { type: :string },
                  address_line_2: { type: :string },
                  zip_code: { type: :string },
                  phone_number: { type: :string },
                  address_for: { type: :string },
                  city: { type: :string },
                  state: { type: :string },
                  landmark: { type: :string },
                  residential: { type: :boolean },
                  is_default: { type: :boolean },
                  deleted_at: { type: :datetime },
                  longitude: { type: :float },
                  latitude: { type: :float },
                  created_at: { type: :datetime },
                  updated_at: { type: :datetime },
                  account:{
                    type: :object,
                    properties:{
                      activated: { type: :boolean },
                      country_code: { type: :string },
                      email: { type: :string },
                      first_name: { type: :string },
                      full_phone_number: { type: :string },
                      last_name: { type: :string },
                      phone_number: { type: :string },
                      type: { type: :string },
                      platform: { type: :string },
                      user_type: { type: :string },
                      status: { type: :string },
                      suspend_until: { type: :string },
                      user_name: { type: :string },
                      created_at: { type: :date },
                      updated_at: { type: :date },
                      device_id: { type: :string },
                      unique_auth_id: { type: :string }
                    }
                  }
                }

              }
            }
        }

        before do |example|
          submit_request(example.metadata)
        end

        it 'Should have status 200' do
          expect(response.status).to eq 200
        end
      end
    end
  end

  path '/order_management/addresses/{id}' do
    get 'Show addresses ' do
      tags 'addresses '
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      parameter name: :id, in: :path, type: :integer
      let!(:address) { FactoryBot.create(:delivery_address, account_id: account.id) }
      let(:id) { address.id }

      response '200', :success do
        before do |example|
          submit_request(example.metadata)
        end

        it 'Should have status 200' do
          expect(response.status).to eq 200
        end

        it 'Should have same reponse' do
          json_response = JSON.parse(response.body)
          expect(json_response["data"]["attributes"]["name"]).to eq address.name
          expect(json_response["data"]["attributes"]["account"]["id"]).to eq account.id
        end
      end
    end

    put 'Update addresses ' do
      tags 'addresses '
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      parameter name: :id, in: :path, type: :integer
      parameter name: :params, in: :body, schema: {
        type: :object,
        properties: {
          address: { type: :string }
        }
      }
      let!(:address) { FactoryBot.create(:delivery_address, account_id: account.id) }
      let(:id) { address.id }

      let(:params) { update_params }

      response '200', :success do
        schema type: :object,
        properties: {
          data: {
            id: { type: :integer },
            type: { type: :string },
            attributes: {
              type: :object,
              properties:{
                id: { type: :integer },
                name: { type: :string },
                flat_no: { type: :string },
                address: { type: :string },
                address_type: { type: :string },
                address_line_2: { type: :string },
                zip_code: { type: :string },
                phone_number: { type: :string },
                address_for: { type: :string },
                city: { type: :string },
                state: { type: :string },
                landmark: { type: :string },
                residential: { type: :boolean },
                is_default: { type: :boolean },
                deleted_at: { type: :datetime },
                longitude: { type: :float },
                latitude: { type: :float },
                created_at: { type: :datetime },
                updated_at: { type: :datetime },
                account:{
                  type: :object,
                  properties:{
                    activated: { type: :boolean },
                    country_code: { type: :string },
                    email: { type: :string },
                    first_name: { type: :string },
                    full_phone_number: { type: :string },
                    last_name: { type: :string },
                    phone_number: { type: :string },
                    type: { type: :string },
                    platform: { type: :string },
                    user_type: { type: :string },
                    status: { type: :string },
                    suspend_until: { type: :string },
                    user_name: { type: :string },
                    created_at: { type: :date },
                    updated_at: { type: :date },
                    device_id: { type: :string },
                    unique_auth_id: { type: :string }
                  }
                }
              }

            }
          }
      }
        before do |example|
          submit_request(example.metadata)
        end

        it 'Should have status 200' do
          expect(response.status).to eq 200
        end

        it 'Should have same reponse' do
          json_response = JSON.parse(response.body)
          expect(json_response["data"]["attributes"]["name"]).to eq address.name
          expect(json_response["data"]["attributes"]["account"]["id"]).to eq account.id
        end
      end
    end

    delete 'Delete a Address' do
      tags 'Address '
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      parameter name: :id, in: :path, type: :integer

      let(:address) { create(:delivery_address, account_id: account.id) }
      let(:id) { address.id }

      response '200', :success do
        schema type: :object,
               properties: {
                 message: { type: :string }
               }

        before do |example|
          submit_request(example.metadata)
        end

        it 'Should have status 200' do
          expect(response.status).to eq 200
        end

        it 'Should have same reponse' do
          json_response = JSON.parse(response.body)
          expect(json_response["message"]).to eq("Address deleted successfully")
        end
      end
    end
  end

end
