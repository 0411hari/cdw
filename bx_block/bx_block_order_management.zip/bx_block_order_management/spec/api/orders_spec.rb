require 'swagger_helper'

RSpec.describe 'bx_block_order_management', :jwt do
  let(:headers) { {:token => token} }

  let(:json)   { JSON response.body }
  let(:data)   { json['data'] }
  let(:token)  { jwt }
  let(:attributes) { data['attributes']}
  let(:errors) { json['errors'] }
  let(:error)  { errors.first }

  let(:account) { create :email_account }
  let(:id)      { account.id }
  let(:token) { BuilderJsonWebToken.encode(account.id, 1.day.from_now, token_type: 'login') }
  let!(:order) { FactoryBot.create(:order, account_id: account.id) }

  let(:update_params) do
    {
      "status" => order.status
    }
  end

  path '/order_management/orders/' do
    post 'Create order ' do
      tags 'order'
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      parameter name: :params, in: :body, schema: {
        type: :object,
        properties: {
          name: { type: :string },
                flat_no: { type: :string },
                order: { type: :string },
                order_type: { type: :string },
                order_line_2: { type: :string },
                zip_code: { type: :string },
                phone_number: { type: :string },
                order_for: { type: :string },
                city: { type: :string },
                state: { type: :string },
                landmark: { type: :string },
                residential: { type: :boolean },
                is_default: { type: :boolean },
                deleted_at: { type: :datetime },
                longitude: { type: :float },
                latitude: { type: :float }

        }
      }

      let(:catalogue) { create :catalogue }
      let(:catalogue_variant) { create :catalogue_variant, catalogue: catalogue }
      let(:coupon_code) { create :coupon_code }
      let(:catalogue_id) { catalogue.id }
      let(:catalogue_variant_id) { catalogue_variant.id }
      let(:params) {{
        catalogue_id: catalogue_id,
        catalogue_variant_id: catalogue_variant_id,
        quantity: 1,
        coupon_code_id: coupon_code.id
      }}

      response '200', :success do
        schema type: :object,
                properties: {
                  data: {
                    id: { type: :integer },
                    type: { type: :string },
                    attributes: {
                      type: :object,
                      properties:{
                        id: { type: :integer },
                        name: { type: :string },
                        flat_no: { type: :string },
                        order: { type: :string },
                        order_type: { type: :string },
                        order_line_2: { type: :string },
                        zip_code: { type: :string },
                        phone_number: { type: :string },
                        order_for: { type: :string },
                        city: { type: :string },
                        state: { type: :string },
                        landmark: { type: :string },
                        residential: { type: :boolean },
                        is_default: { type: :boolean },
                        deleted_at: { type: :datetime },
                        longitude: { type: :float },
                        latitude: { type: :float },
                        created_at: { type: :datetime },
                        updated_at: { type: :datetime },
                        account:{
                          type: :object,
                          properties:{
                            activated: { type: :boolean },
                            country_code: { type: :string },
                            email: { type: :string },
                            first_name: { type: :string },
                            full_phone_number: { type: :string },
                            last_name: { type: :string },
                            phone_number: { type: :string },
                            type: { type: :string },
                            platform: { type: :string },
                            user_type: { type: :string },
                            status: { type: :string },
                            suspend_until: { type: :string },
                            user_name: { type: :string },
                            created_at: { type: :date },
                            updated_at: { type: :date },
                            device_id: { type: :string },
                            unique_auth_id: { type: :string }
                          }
                        }
                      }

                    }
                  }
                }

        before do |example|
          submit_request(example.metadata)
        end

        it 'Should have status 200' do
          expect(response.status).to eq 200
        end

        it 'Should have same response Account Id' do
          json_response = JSON.parse(response.body)
          expect(json_response["data"]["order"]["data"]["attributes"]["account_id"]).to eq account.id
        end
      end
      response '400', :unauthorized do
        let(:token)  { '' }

        run_test!
      end

      response '401', :unauthorized do
        let(:token)  { jwt_expired }

        run_test!
      end

    end

    get 'List of orderes  ' do
      tags 'orderes '
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      let!(:order) {FactoryBot.create(:order, account_id: account.id)}

      response '200', :success do
        schema type: :object,
          properties: {
            data: {
              id: { type: :integer },
              type: { type: :string },
              attributes: {
                type: :object,
                properties:{
                  id: { type: :integer },
                  order_number: { type: :string },
                  amount: { type: :float },
                  account_id: { type: :integer },
                  coupon_code_id: { type: :integer },
                  delivery_address_id: { type: :integer },
                  sub_total: { type: :decimal },
                  total: { type: :decimal },
                  status: { type: :string },
                  applied_discount: { type: :decimal },
                  cancellation_reason: { type: :string },
                  order_date: { type: :datetime },
                  is_gift: { type: :boolean },
                  source: { type: :string },
                  shipment_id: { type: :string },
                  delivery_charges: { type: :string },
                  tracking_url: { type: :string },
                  placed_at: { type: :datetime },
                  confirmed_at: { type: :datetime },
                  in_transit_at: { type: :datetime },
                  delivered_at: { type: :datetime },
                  cancelled_at: { type: :datetime },
                  refunded_at: { type: :datetime },
                  placed_at: { type: :datetime },
                  schedule_time: { type: :datetime },
                  payment_failed_at: { type: :datetime },
                  payment_pending_at: { type: :datetime },
                  deliver_by: { type: :integer },
                  shipping_total: { type: :decimal },
                  shipping_net_amt: { type: :decimal },
                  shipping_discount: { type: :decimal },
                  shipping_charge: { type: :decimal },
                  total_tax: { type: :float },
                  tax_charges: { type: :decimal },
                  is_group: { type: :boolean },
                  order_status_id: { type: :integer },
                  is_availability_checked: { type: :boolean },
                  razorpay_order_id: { type: :string },
                  created_at: { type: :datetime },
                  updated_at: { type: :datetime },
                  account:{
                    type: :object,
                    properties:{
                      activated: { type: :boolean },
                      country_code: { type: :string },
                      email: { type: :string },
                      first_name: { type: :string },
                      full_phone_number: { type: :string },
                      last_name: { type: :string },
                      phone_number: { type: :string },
                      type: { type: :string },
                      platform: { type: :string },
                      user_type: { type: :string },
                      status: { type: :string },
                      suspend_until: { type: :string },
                      user_name: { type: :string },
                      created_at: { type: :date },
                      updated_at: { type: :date },
                      device_id: { type: :string },
                      unique_auth_id: { type: :string }
                    }
                  }
                }

              }
            }
        }

        before do |example|
          submit_request(example.metadata)
        end

        it 'Should have status 200' do
          expect(response.status).to eq 200
        end
      end
    end
  end

  path '/order_management/orders/{id}' do
    get 'Show orderes ' do
      tags 'orderes '
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      parameter name: :id, in: :path, type: :integer
      let!(:order) { FactoryBot.create(:order, account_id: account.id) }
      let(:id) { order.id }

      response '200', :success do
        before do |example|
          submit_request(example.metadata)
        end

        it 'Should have status 200' do
          expect(response.status).to eq 200
        end

        it 'Should have same reponse' do
          json_response = JSON.parse(response.body)
          expect(json_response["data"]["attributes"]["order_number"]).to eq order.order_number
        end
      end
    end

    delete 'Delete a order' do
      tags 'order '
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      parameter name: :id, in: :path, type: :integer

      let(:order) { FactoryBot.create(:order, account_id: account.id) }
      let(:id) { order.id }

      response '200', :success do
        schema type: :object,
               properties: {
                 message: { type: :string }
               }

        before do |example|
          submit_request(example.metadata)
        end

        it 'Should have status 200' do
          expect(response.status).to eq 200
        end

        it 'Should have same reponse' do
          json_response = JSON.parse(response.body)
          expect(json_response["message"]).to eq("Order deleted successfully")
        end
      end
    end
  end

    path '/order_management/orders/{id}/cancel_order' do
        put 'Cancel orderes ' do
            tags 'orderes '
            parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
            parameter name: :id, in: :path, type: :integer
            parameter name: :params, in: :body, schema: {
                type: :object,
                properties: {
                    status: { type: :string }
                }
            }
            let!(:order) { FactoryBot.create(:order, account_id: account.id) }
            let(:id) { order.id }

            let(:params) { update_params}

            response '200', :success do
              schema type: :object,
              properties: {
                data: {
                  id: { type: :integer },
                  type: { type: :string },
                  attributes: {
                    type: :object,
                    properties:{
                      id: { type: :integer },
                      order_number: { type: :string },
                      amount: { type: :float },
                      account_id: { type: :integer },
                      coupon_code_id: { type: :integer },
                      delivery_address_id: { type: :integer },
                      sub_total: { type: :decimal },
                      total: { type: :decimal },
                      status: { type: :string },
                      applied_discount: { type: :decimal },
                      cancellation_reason: { type: :string },
                      order_date: { type: :datetime },
                      is_gift: { type: :boolean },
                      source: { type: :string },
                      shipment_id: { type: :string },
                      delivery_charges: { type: :string },
                      tracking_url: { type: :string },
                      placed_at: { type: :datetime },
                      confirmed_at: { type: :datetime },
                      in_transit_at: { type: :datetime },
                      delivered_at: { type: :datetime },
                      cancelled_at: { type: :datetime },
                      refunded_at: { type: :datetime },
                      placed_at: { type: :datetime },
                      schedule_time: { type: :datetime },
                      payment_failed_at: { type: :datetime },
                      payment_pending_at: { type: :datetime },
                      deliver_by: { type: :integer },
                      shipping_total: { type: :decimal },
                      shipping_net_amt: { type: :decimal },
                      shipping_discount: { type: :decimal },
                      shipping_charge: { type: :decimal },
                      total_tax: { type: :float },
                      tax_charges: { type: :decimal },
                      is_group: { type: :boolean },
                      order_status_id: { type: :integer },
                      is_availability_checked: { type: :boolean },
                      razorpay_order_id: { type: :string },
                      created_at: { type: :datetime },
                      updated_at: { type: :datetime },
                      account:{
                        type: :object,
                        properties:{
                          activated: { type: :boolean },
                          country_code: { type: :string },
                          email: { type: :string },
                          first_name: { type: :string },
                          full_phone_number: { type: :string },
                          last_name: { type: :string },
                          phone_number: { type: :string },
                          type: { type: :string },
                          platform: { type: :string },
                          user_type: { type: :string },
                          status: { type: :string },
                          suspend_until: { type: :string },
                          user_name: { type: :string },
                          created_at: { type: :date },
                          updated_at: { type: :date },
                          device_id: { type: :string },
                          unique_auth_id: { type: :string }
                        }
                      }
                    }
                  }
                }
            }

            before do |example|
            submit_request(example.metadata)
            end

            it 'Should have status 200' do
            expect(response.status).to eq 200
            end

            it 'Should have same reponse' do
            json_response = JSON.parse(response.body)
            expect(json_response["message"]).to eq("Order cancelled successfully")
            end
          end
        end
    end

    path '/order_management/orders/{id}/update_order_status' do
      put 'Update ordere status ' do
          tags 'orderes '
          parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
          parameter name: :id, in: :path, type: :integer
          parameter name: :params, in: :body, schema: {
              type: :object,
              properties: {
                  status: { type: :string }
              }
          }
          let!(:order) { FactoryBot.create(:order, account_id: account.id) }
          let(:id) { order.id }

          let(:params) { update_params}

          response '200', :success do
            schema type: :object,
            properties: {
              data: {
                id: { type: :integer },
                type: { type: :string },
                attributes: {
                  type: :object,
                  properties:{
                    id: { type: :integer },
                    order_number: { type: :string },
                    amount: { type: :float },
                    account_id: { type: :integer },
                    coupon_code_id: { type: :integer },
                    delivery_address_id: { type: :integer },
                    sub_total: { type: :decimal },
                    total: { type: :decimal },
                    status: { type: :string },
                    applied_discount: { type: :decimal },
                    cancellation_reason: { type: :string },
                    order_date: { type: :datetime },
                    is_gift: { type: :boolean },
                    source: { type: :string },
                    shipment_id: { type: :string },
                    delivery_charges: { type: :string },
                    tracking_url: { type: :string },
                    placed_at: { type: :datetime },
                    confirmed_at: { type: :datetime },
                    in_transit_at: { type: :datetime },
                    delivered_at: { type: :datetime },
                    cancelled_at: { type: :datetime },
                    refunded_at: { type: :datetime },
                    placed_at: { type: :datetime },
                    schedule_time: { type: :datetime },
                    payment_failed_at: { type: :datetime },
                    payment_pending_at: { type: :datetime },
                    deliver_by: { type: :integer },
                    shipping_total: { type: :decimal },
                    shipping_net_amt: { type: :decimal },
                    shipping_discount: { type: :decimal },
                    shipping_charge: { type: :decimal },
                    total_tax: { type: :float },
                    tax_charges: { type: :decimal },
                    is_group: { type: :boolean },
                    order_status_id: { type: :integer },
                    is_availability_checked: { type: :boolean },
                    razorpay_order_id: { type: :string },
                    created_at: { type: :datetime },
                    updated_at: { type: :datetime },
                    account:{
                      type: :object,
                      properties:{
                        activated: { type: :boolean },
                        country_code: { type: :string },
                        email: { type: :string },
                        first_name: { type: :string },
                        full_phone_number: { type: :string },
                        last_name: { type: :string },
                        phone_number: { type: :string },
                        type: { type: :string },
                        platform: { type: :string },
                        user_type: { type: :string },
                        status: { type: :string },
                        suspend_until: { type: :string },
                        user_name: { type: :string },
                        created_at: { type: :date },
                        updated_at: { type: :date },
                        device_id: { type: :string },
                        unique_auth_id: { type: :string }
                      }
                    }
                  }
                }
              }
          }

          before do |example|
          submit_request(example.metadata)
          end

          it 'Should have status 200' do
          expect(response.status).to eq 200
          end

          it 'Should have same reponse' do
          json_response = JSON.parse(response.body)
          expect(json_response["data"]["id"]).to eq order.id.to_s
          end
        end
      end
    end

    path '/order_management/orders/{id}/add_address_to_order' do
      put 'Add Address to Order ' do
          tags 'orderes '
          parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
          parameter name: :id, in: :path, type: :integer
          parameter name: :params, in: :body, schema: {
              type: :object,
              properties: {
                  status: { type: :string }
              }
          }
          let!(:order) { FactoryBot.create(:order, account_id: account.id) }
          let!(:address) { FactoryBot.create(:delivery_address, account_id: account.id) }
          let(:id) { order.id }

          let(:billing_address_details) do 
            {
              "delivery_address_id" => address.id, 
              "address" => 
              {
                "billing_address" => {
                    "name" => 'Address 1',
                    "flat_no" => 10,
                    "address_type" => 'home',
                    "address" => 'Street 1 building 2',
                    "address_line_2" => 'Some details',
                    "zip_code" => 100,
                    "phone_number" => '+380268294322'
                }
              }   
            }
          end
        

          let(:params) { billing_address_details}

          response '200', :success do
              schema type: :object,
                  properties: {
                      status: { type: :string }
                  }

              before do |example|
              submit_request(example.metadata)
              end

              it 'Should have status 200' do
              expect(response.status).to eq 200
              end

              it 'Should have same reponse' do
              json_response = JSON.parse(response.body)
              end
          end
      end
    end

    # path '/order_management/orders/{id}/update_payment' do
    #   put 'Update payment ordere ' do
    #       tags 'orderes '
    #       parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
    #       parameter name: :id, in: :path, type: :integer
    #       parameter name: :params, in: :body, schema: {
    #           type: :object,
    #           properties: {
    #               status: { type: :string }
    #           }
    #       }
    #       let!(:order) { FactoryBot.create(:order, account_id: account.id) }
    #       let(:id) { order.id }

    #       let(:params) { update_params}

    #       response '200', :success do
    #           schema type: :object,
    #               properties: {
    #                   status: { type: :string }
    #               }

    #           before do |example|
    #           submit_request(example.metadata)
    #           end

    #           it 'Should have status 200' do
    #           expect(response.status).to eq 200
    #           end

    #           it 'Should have same reponse' do
    #           json_response = JSON.parse(response.body)
    #           end
    #       end
    #   end
    # end
end

