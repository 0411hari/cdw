# BxBlockStripeIntegration
Short description and motivation.

## Usage
How to use my plugin.

## Installation
Add this line to your application's Gemfile:

```ruby
gem 'bx_block_stripe_integration'
```

And then execute:
```bash
$ bundle
```

Or install it yourself as:
```bash
$ gem install bx_block_stripe_integration
```

## Contributing
Contribution directions go here.
