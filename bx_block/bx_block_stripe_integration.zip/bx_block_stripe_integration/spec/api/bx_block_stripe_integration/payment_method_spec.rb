require 'rails_helper'
require 'swagger_helper'

RSpec.describe '/stripe_integration/payment_methods', :jwt do
  let(:headers) { {:token => jwt_token} }
  let(:jwt_token) { BuilderJsonWebToken.encode(account.id) }
  let(:json)   { JSON response.body }
  let(:meta)   { json['meta'] }
  let(:errors) { json['errors'] }
  let(:error)  { errors.first }
  let(:strip_token_id) { OpenStruct.new(id: 'token_id_50sX9hGHZJvjjI') }
  let(:subscription) { OpenStruct.new(id: 'subscription_id_50sX9hGHZJvjjI') }
  let(:payment_method) { BxBlockStripeIntegration::PaymentMethod.last }
  let(:payment) { BxBlockStripeIntegration::Payment.last }

  let(:strip_charge) { OpenStruct.new(id: 'charge_id_50sX9hGHZJvjjI') }


  describe 'POST /stripe_integration/payment_methods' do
    let(:params) {{
      :data => {
        :type => 'email_account',
        :attributes => {
          :email => account.email,
          :password => password,
        },
      },
    }}

    before do
      allow(Stripe::Customer).to receive(:create) { OpenStruct.new(id: account.id) }
      allow(Stripe::Token).to receive(:create) { OpenStruct.new(id: strip_token_id.id) }
      allow(Stripe::Customer).to receive(:create_source) { OpenStruct.new(id: account.id) }
      allow(Stripe::Subscription).to receive(:create) { OpenStruct.new(id: subscription.id) }
      allow(Stripe::Subscription).to receive(:delete) { OpenStruct.new(id: subscription.id) }
      allow(Stripe::Charge).to receive(:create) { OpenStruct.new(id: strip_charge.id) }


      stripe_customer = Stripe::Customer.create({email:  account.email})
      account.update(stripe_id: stripe_customer.id)
      card = Stripe::Token.create({card: {number: '4242424242424242',exp_month: 11,exp_year: 2021,cvc: '314',},})
      Stripe::Customer.create_source(account.stripe_id,{source: card.id},)
    end

    let(:observed_response_json) do
      {
        "data"=> {
          "id"=> payment_method.id.to_s,
          "type"=> "payment_method",  
          "attributes"=> {
            "account_id"=> payment_method.account_id,
            "card_token"=> payment_method.card_token,
            "is_primary"=> payment_method.is_primary,
          }
        },
        "meta" =>{
          "card" => {
            "table" => {
              "id" => strip_token_id.id
            }
          }
        }
      }
    end

    let(:observed_create_subscription_response) do
      {
        "data"=> {
          "id"=> account.id.to_s,
          "type"=> "email_account",  
          "attributes"=> {
            "first_name"=> account.first_name,
            "last_name"=> account.last_name,
            "full_phone_number"=> account.full_phone_number,
            "country_code"=> account.country_code,
            "phone_number"=> account.phone_number,
            "email"=> account.email,
            "activated"=> account.activated,
          }
        },
        "meta" =>{
          "token" => jwt_token,
        }
      }
    end

    let(:observed_stripe_payment_response) do
      {
        "data"=> {
          "id"=> payment.id.to_s,
          "type"=> "payment",  
          "attributes"=> {
            "ammount"=> payment.ammount,
          }
        }
      }
    end

    context 'Create Subscription' do
      let(:password) { 'my-password' }

      let(:account)  do
        create :email_account,
          :activated => true,
          :password  => password
      end

      path '/stripe_integration/payment_methods/create_subscription' do
        post 'Create subscription' do
          tags 'PaymentMethods'
          consumes 'application/json'

          parameter name: :body, in: :body, schema: {
            type: :object,
            properties: {
              data: { 
                type: :object, 
                properties: {
                  type: { type: :string },
                  attributes: { 
                    type: :object, 
                    properties: { 
                      email: { type: :string },
                      password: { type: :string }
                    }
                  }
                }
              }
            }
          }

          parameter name: :token, in: :header, type: :string

          response '201', 'Create subscription' do
            let(:body) { params }
            let(:token) { jwt_token }

            run_test!
          end
        end
      end

      it 'create_subscription having status 201' do
        post '/stripe_integration/payment_methods/create_subscription',as: :json, headers: headers, :params => params
        expect(response.status).to eq 201
      end

      it 'same response' do
        post '/stripe_integration/payment_methods/create_subscription',as: :json, headers: headers, :params => params
        json_response = JSON.parse(response.body)
        expect(json_response).to eq(observed_create_subscription_response)
      end
    end

    context 'Cancel Subscription' do
      let(:password) { 'my-password' }

      let(:account)  do
        create :email_account,
          :activated => true,
          :password  => password
      end

      path '/stripe_integration/payment_methods/cancel_subscription' do
        post 'Cancel subscription' do
          tags 'PaymentMethods'
          consumes 'application/json'

          parameter name: :body, in: :body, schema: {
            type: :object,
            properties: {
              account_id: { type: :integer }
            }
          }

          parameter name: :token, in: :header, type: :string

          response '201', 'Cancel subscription' do
            let(:body) { { account_id: account.id } }
            let(:token) { jwt_token }

            run_test!
          end
        end
      end

      it 'cancel_subscription' do
        account.update(stripe_subscription_id: subscription.id)
        post '/stripe_integration/payment_methods/cancel_subscription',as: :json, headers: headers, :params => {account_id: account.id}
        expect(response.status).to eq 201
      end

      it 'have same json reposne' do
        account.update(stripe_subscription_id: subscription.id)
        post '/stripe_integration/payment_methods/cancel_subscription',as: :json, headers: headers, :params => {account_id: account.id}
        json_response = JSON.parse(response.body)
        expect(json_response).to eq(observed_create_subscription_response)
      end
    end

    context 'Create Customer Card' do
      let(:password) { 'my-password' }
      
      let(:account)  do
        create :email_account,
          :activated => true,
          :password  => password
      end

      let(:customer_card_params) {
        {
          data: {
            type: "authors",
            attributes: {
              number: "4242424242424242",
              exp_month: 11,
              exp_year: 2021,
              cvc: '314'
            }
          }
        }
      }

      path '/stripe_integration/payment_methods/create_customer_card' do
        post 'Create customer card' do
          tags 'PaymentMethods'
          consumes 'application/json'

          parameter name: :body, in: :body, schema: {
            type: :object,
            properties: {
              data: { 
                type: :object, 
                properties: {
                  type: { type: :string },
                  attributes: { 
                    type: :object, 
                    properties: { 
                      number: { type: :string },
                      exp_month: { type: :string },
                      exp_year: { type: :string },
                      cvc: { type: :string }
                    }
                  }
                }
              }
            }
          }

          parameter name: :token, in: :header, type: :string

          response '201', 'Create customer card' do
            let(:body) { customer_card_params }
            let(:token) { jwt_token }

            run_test!
          end
        end
      end

      it 'Create Customer Card' do
        post '/stripe_integration/payment_methods/create_customer_card',as: :json, headers: headers, :params => {"data"=>{"type"=>"authors", "attributes"=>{:number=>"4242424242424242", :exp_month=>11, :exp_year => 2021, :cvc => '314'}}}
        expect(response.status).to eq 201
      end

      it 'Create Customer Card with same response' do
        post '/stripe_integration/payment_methods/create_customer_card',as: :json, headers: headers, :params => {"data"=>{"type"=>"authors", "attributes"=>{:number=>"4242424242424242", :exp_month=>11, :exp_year => 2021, :cvc => '314'}}}
        json_response = JSON.parse(response.body)
        expect(json_response).to eq(observed_response_json)
      end
    end

    context 'Create Payments' do
      let(:password) { 'my-password' }

      let(:account)  do
        create :email_account,
          :activated => true,
          :password  => password
      end

      let(:payment_params) {
        {
          data: {
            type: "email_account",
            attributes: {
              ammount: 200000,
              account_id: account.id
            }
          }
        }
      }

      path '/stripe_integration/payment_methods/create_payments' do
        post 'Create payment' do
          tags 'PaymentMethods'
          consumes 'application/json'

          parameter name: :body, in: :body, schema: {
            type: :object,
            properties: {
              data: { 
                type: :object, 
                properties: {
                  type: { type: :string },
                  attributes: { 
                    type: :object, 
                    properties: { 
                      account_id: { type: :integer },
                      ammount: { type: :integer }
                    }
                  }
                }
              }
            }
          }

          parameter name: :token, in: :header, type: :string

          response '201', 'Create payment' do
            let(:body) { payment_params }
            let(:token) { jwt_token }

            run_test!
          end
        end
      end

      it 'Create Payments' do
        post '/stripe_integration/payment_methods/create_payments',as: :json, headers: headers, :params => {"data"=>{"type"=>"email_account", "attributes"=>{:ammount=>"200000", :account_id=>account.id}}}
        expect(response.status).to eq 201
      end

      it 'Create Payments have same response' do
        post '/stripe_integration/payment_methods/create_payments',as: :json, headers: headers, :params => {"data"=>{"type"=>"email_account", "attributes"=>{:ammount=>"200000", :account_id=>account.id}}}
        json_response = JSON.parse(response.body)
        expect(json_response).to eq(observed_stripe_payment_response)
      end
    end

    context 'Create Payments Invalid data format' do
      let(:password) { 'my-password' }

      let(:account)  do
        create :email_account,
          :activated => true,
          :password  => password
      end

      it 'Create Payments Invalid data format' do
        token = BuilderJsonWebToken.encode(account.id)
        stripe_customer = Stripe::Customer.create({email:  account.email})
        account.update(stripe_id: stripe_customer.id)
        card = Stripe::Token.create({card: {number: '4242424242424242',exp_month: 11,exp_year: 2021,cvc: '314',},})
        Stripe::Customer.create_source(account.stripe_id,{source: card.id},)
        post '/stripe_integration/payment_methods/create_payments',as: :json, headers: headers, :params => {"data"=>{"type"=>"email_account", "attributes"=>{:ammount=>"200000", :account_id=>''}}}
        expect(response.status).to eq 422
        expect(JSON.parse(response.body)["errors"].first["account"]).to match(/Invalid data format/)
      end
    end
  end
end
