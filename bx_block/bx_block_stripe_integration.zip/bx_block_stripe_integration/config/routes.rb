BxBlockStripeIntegration::Engine.routes.draw do

  mount Rswag::Ui::Engine => '/api-docs' if defined?(Rswag) && defined?(Rswag::Ui)
  mount Rswag::Api::Engine => '/api-docs' if defined?(Rswag) && defined?(Rswag::Api)

  post "/payment_methods/create_customer_card", to: "payment_methods#create_customer_card"
  post "/payment_methods/create_payments", to: "payment_methods#create_payments"
  post "/payment_methods/create_subscription", to: "payment_methods#create_subscription"
  post "/payment_methods/cancel_subscription", to: "payment_methods#cancel_subscription"
end
