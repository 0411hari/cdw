require "stripe"
Stripe.api_key = ENV['STRIPE_SECRET_KEY']
module BxBlockStripeIntegration
  class InvoiceBilling
    attr_accessor :params,  :user

    def initialize(params, user)
        @params = params
        @user = user
    end

    def product
        Stripe::Product.create({name: 'Gold Special'})
    end

    def price(product, amount)
        Stripe::Price.create({
        unit_amount: amount,
        currency: 'inr',
        product: product,
        })
    end

    def invoice_items(stripe_id, price)
        Stripe::InvoiceItem.create({
        customer: stripe_id,
        price: price,
        })
    end

    def draft_invoice(stripe_id)
        Stripe::Invoice.create({
        customer: stripe_id,
        })
    end
  end
end