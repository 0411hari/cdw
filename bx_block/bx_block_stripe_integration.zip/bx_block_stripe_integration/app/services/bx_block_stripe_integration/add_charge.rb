require "stripe"
Stripe.api_key = ENV['STRIPE_SECRET_KEY']
module BxBlockStripeIntegration
  class AddCharge
    attr_accessor :params,  :user

    def initialize(params, user)
        @params = params
        @user = user
    end

    def create_card(user, card_params)
        card = create_card_token(card_params)
    end


    def create_card_token(card_params)
        begin
            return Stripe::Token.create(card: card_params)
        rescue Stripe::StripeError => e
            logger.debug e
            raise
        end
    end

    def create_customer_source(stripe_id, token)
        begin
            return Stripe::Customer.create_source(
            stripe_id,
            {source: token},
            )
        rescue Stripe::StripeError => e
            logger.debug e
            raise
        end
    end
    def card_retrieve_source(stripe_id, card)
        Stripe::Customer.retrieve_source(
            stripe_id ,
            card,
      )
    end

    def payment_intent(stripe_id, payment_method,amount)
        charge = Stripe::PaymentIntent.create({
            amount: amount,
            currency: 'usd',
            payment_method_types: ['card'],
            payment_method: payment_method,
            customer: stripe_id,
            use_stripe_sdk: true
          })
    end
  end
end

# card_token = BxBlockStripeIntegration::AddCharge.new(params, @current_user).create_card_token(card_params)
#           create_source = BxBlockStripeIntegration::AddCharge.new(params, user).create_customer_source(user.stripe_id, card_token.id)
#           card_details = BxBlockStripeIntegration::AddCharge.new(params, user).card_retrieve_source(user.stripe_id, create_source.id)

#             charge = Stripe::PaymentIntent.create({
#               amount: 120,
#               currency: 'usd',
#               payment_method_types: ['card'],
#               payment_method: create_source.id,
#               customer: user.stripe_id,
#               # ephemeralKey: ephemeralKey[:secret]
#               confirm: true,
#               use_stripe_sdk: true
#             })

#             draft_invoice = Stripe::Invoice.create({
#               customer:  user.stripe_id,
#             })