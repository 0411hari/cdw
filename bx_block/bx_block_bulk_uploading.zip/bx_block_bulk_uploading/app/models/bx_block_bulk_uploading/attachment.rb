module BxBlockBulkUploading
  class Attachment < BxBlockBulkUploading::ApplicationRecord
    self.table_name = :attachments
    include Wisper::Publisher

    has_many_attached :files
    belongs_to :account, class_name: 'AccountBlock::Account'
    validates :files, attached: true,
              limit: { min: 1, max: 10 },
              size: { less_than: 5.megabytes , message: 'is not given between size' },
              content_type: [:png, :jpg, :jpeg, :pdf]
  end
end
