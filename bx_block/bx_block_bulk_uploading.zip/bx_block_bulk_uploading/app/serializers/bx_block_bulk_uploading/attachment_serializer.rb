module BxBlockBulkUploading
  class AttachmentSerializer < BuilderBase::BaseSerializer
    attributes *[
      :id, :account_id, :colour, :layout, :page_size, :scale, :print_sides,
      :print_pages_from, :print_pages_to, :total_pages, :total_attachment_pages,  :is_expired, :pdf_url, :is_printed, :files
    ]

    attribute :files do |object|
      if object.files.attached?
        arr = []
        object.files.each do |picture|
          arr << {
            file_name: picture.filename.to_s
          }
        end
        arr
      end
    end
    # attribute :attachment_path do |object|
    #   attachment object
    # end

    # attribute :content_type do |object|
    #   object&.attachment_blob&.content_type
    # end

    # attribute :file_name do |object|
    #   object&.attachment_blob&.filename.to_s
    # end
    class << self
      private
      def attachment(object)
        object&.attachment&.service_url if object&.attachment&.attached?
      end
    end
  end
end
