module BxBlockBulkUploading
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
