require 'open-uri'
require 'tmpdir'
require 'libreconv'
require 'aws-sdk'
require 'aws-sdk-s3'
require 'base64'

module BxBlockBulkUploading
  class AttachmentsController < ApplicationController
    include BuilderJsonWebToken::JsonWebTokenValidation
    # before_action :validate_json_web_token, :validate_blacklisted_user
    before_action :current_user
    # before_action :add_allow_credentials_headers, only: [:create]
    def create
      attachment = Attachment.new(attachments_params.merge(account_id: current_user.id))
      if attachment.save
        render json: AttachmentSerializer.new(attachment, meta: {
          message: "Attachment Created Successfully"
        }).serializable_hash, status: :created
      else
        render json: { status: :unprocessable_entity }
      end
    end

    def destroy
      attachment = Attachment.find(params[:id])
      return render json: {message: "attachment does not exist."},
             status: :unprocessable_entity if !attachment.present?
      if attachment.destroy
        render json: {message: "Deleted."}, status: :ok
      else
        render json: {errors: format_activerecord_errors(attachment.errors)},
               status: :unprocessable_entity
      end
    end

    private
    def attachments_params
      params.permit(:colour, :layout, :page_size, :pdf_url, :scale,
                                              :print_sides,:print_pages_from, :print_pages_to,
                                              :total_attachment_pages, :total_pages, :is_expired,:account_id,
                                              files: [])
    end

    def add_allow_credentials_headers
      headers['Access-Control-Allow-Origin'] = '*'
      headers['Access-Control-Allow-Methods'] = 'POST, PUT, DELETE, GET, OPTIONS'
      headers['Access-Control-Request-Method'] = '*'
      headers['Access-Control-Allow-Headers'] = 'Origin, X-Requested-With, Content-Type, Accept, Authorization'
    end

    def format_activerecord_errors(errors)
      result = []
      errors.each do |attribute, error|
        result << { attribute => error }
      end
      result
    end
  end
end
