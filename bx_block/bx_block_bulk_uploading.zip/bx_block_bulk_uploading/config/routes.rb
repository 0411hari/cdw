BxBlockBulkUploading::Engine.routes.draw do
  mount Rswag::Ui::Engine => '/api-docs'
  mount Rswag::Api::Engine => '/api-docs'
  resources :attachments, only: %i(create destroy)
end