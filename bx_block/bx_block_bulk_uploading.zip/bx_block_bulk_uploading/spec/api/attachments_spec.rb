require 'swagger_helper'
include ActionDispatch::TestProcess
RSpec.describe '/bx_block_bulk_uploading', :jwt do
  let(:json)   { JSON response.body }
  let(:data)   { json['data'] }
  let(:token)  { jwt }
  let(:attributes) { data['attributes']}
  let(:errors) { json['errors'] }
  let(:error)  { errors.first }
  let(:model_errors) { data['attributes']['errors'] }
  let(:model_error)  { errors.first }
  let(:account) { create :email_account }
  let(:id)      { account.id }
  let(:token) { BuilderJsonWebToken.encode(account.id, 1.day.from_now, token_type: 'login') }
  let(:new_image) { blob_for('support/image_test_new.jpg').signed_id }

  let(:bulk_uploading_params) do
    {
      "files" => [new_image],
      "colour" => "red",
      "layout" => "testing",
      "page_size"=> "3",
      "scale" => "test",
      "print_sides" => "print_sides",
      "print_pages_from" => "",
      "print_pages_to" => "",
      "total_pages" => "",
      "total_attachment_pages" => "3",
      "is_expired" => "",
      "pdf_url" => "pdf_url",
      "is_printed" => ""
    }
  end

  path '/bulk_uploading/attachments/{id}' do
    delete 'Delete a Bulkuploading' do
      tags ' Bulkuploading'
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      parameter name: :id, in: :path, type: :integer
      # let!(:attachment) { create(:attachment, account_id: account.id)}
      let!(:attachment) { FactoryBot.create(:attachment, account_id: account.id)}
      let(:id) { attachment.id }
      response '200', :success do
        schema type: :object,
               properties: {
                 message: { type: :string }
               }
        before do |example|
          submit_request(example.metadata)
        end
        it 'Should have status 200' do
          expect(response.status).to eq 200
        end
        it 'Should have same reponse' do
          json_response = JSON.parse(response.body)
          expect(json_response["message"]).to eq("Deleted.")
        end
      end
    end
  end

  path '/bulk_uploading/attachments' do
    post 'Create Bulk Uploading' do
      tags 'Bulk Uploading'
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      parameter name: :params, in: :body, schema: {
        type: :object,
        properties: {
          colour: { type: :string },
          layout: { type: :string },
          page_size: { type: :string },
          scale: { type: :string },
          print_sides: { type: :string },
          print_pages_from: { type: :integer },
          print_pages_to: { type: :integer },
          total_pages: { type: :integer },
          total_attachment_pages: { type: :integer },
          is_expired: { type: :boolean },
          pdf_url: { type: :string },
          is_printed: { type: :boolean },
          account_id: { type: :integer },
          files: { type: :file }
        }
      }

      let(:params) {bulk_uploading_params}
      response '201', :success do
        schema type: :object,
                properties: {
                  data: {
                    type: :object,
                    properties: {
                      id: { type: :integer },
                      type: { type: :string },
                      attributes: {
                        account_id: { type: :integer },
                        created_at: { type: :date },
                        updated_at: { type: :date },
                        image: { type: :file }
                      }
                    }
                  }
                }

        before do |example|
          submit_request(example.metadata)
        end

        it 'Should have status 201' do
          expect(response.status).to eq 201
        end

        it 'Should have same response description' do
          json_response = JSON.parse(response.body)
          expect(json_response["data"]["attributes"]["account_id"]).to eq(id)
        end
      end

      response '400', :unauthorized do
        let(:token)  { '' }

        run_test!
      end

      response '401', :unauthorized do
        let(:token)  { jwt_expired }

        run_test!
      end
    end
  end


end
