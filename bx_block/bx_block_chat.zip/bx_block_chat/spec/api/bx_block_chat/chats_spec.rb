require 'swagger_helper'

RSpec.describe '/chat', :jwt do
  let(:endpoint) { '/chat/chats' }

  let(:headers) { {:token => token} }

  let(:json) { JSON response.body }
  let(:data) { json['data'] }
  let(:token) { jwt }
  let(:jwt_token)  { jwt }
  let(:attributes) { data['attributes'] }
  let(:errors) { json['errors'] }
  let(:error) { errors.first }
  let(:model_errors) { data['attributes']['errors'] }
  let(:model_error) { errors.first }

  let(:account) { create :email_account }
  let(:id) { account.id }



  path '/chat/chats' do
    post 'Create a chat room' do
      tags 'Chats'
      # First authentication header
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      # Declare request parametes
      parameter name: :chat, in: :body, schema: {
        type: :object,
        properties: {
          name: { type: :string }
        }
      }

      let(:chat) {{
        name: 'test'
      }}
      # Create factories that you would need in this endpoint test
      response '201', :success do
        schema type: :object,
                properties: {
                  data: {
                    type: :object,
                    properties: {
                      id: { type: :string },
                      type: { type: :string },
                      attributes: {
                        type: :object,
                        properties:{
                          id: { type: :integer },
                          name: { type: :string },
                        }
                      },
                      relationships:{
                        type: :object,
                        properties:{
                          accounts:{
                            type: :object,
                            properties:{
                              data: {
                                type: :array,
                                items: {
                                  properties: {
                                    id: { type: :integer },
                                    type: { type: :string },
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }

        before do |example|
          submit_request(example.metadata)
        end

        it 'creates chat record' do |_|
          # Check response contents
          expect(response.status).to eq 201
          expect(BxBlockChat::Chat.count).to eq 1
        end
      end

      response '400', :unauthorized do
        let(:token)  { '' }
        run_test!
      end
    end
  end

  path '/chat/chats' do
    get 'List of Chats' do
      let!(:chat) { create :chat, name: 'test' }
      let!(:account_chat) { create :account_chat, account_id: account.id, chat_id: chat.id }
      let!(:chat1) { create :chat, name: 'test1' }
      let!(:account_chat2) { create :account_chat, account_id: account.id, chat_id: chat1.id }
      tags 'Chats'
      # First authentication header
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      # Declare request parametes

      # Create factories that you would need in this endpoint test
      response '200', :success do
        schema type: :object,
                properties: {
                  data: {
                    type: :array,
                    items: {
                      type: :object,
                      properties: {
                        id: { type: :string },
                        type: { type: :string },
                        attributes: {
                          type: :object,
                          properties:{
                            id: { type: :integer },
                            name: { type: :string },
                          }
                        },
                        relationships:{
                          type: :object,
                          properties:{
                            accounts:{
                              type: :object,
                              properties:{
                                data: {
                                  type: :array,
                                  items: {
                                    properties: {
                                      id: { type: :integer },
                                      type: { type: :string },
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }

        before do |example|
          submit_request(example.metadata)
        end

        it 'list chat record' do
          # Check response contents
          expect(response.status).to eq 200
          expect(BxBlockChat::Chat.count).to eq 2
        end
      end

      response '400', :unauthorized do
        let(:token)  { '' }
        run_test!
      end
    end
  end

  path '/chat/chats/{id}' do
    get 'Show Chat' do
      tags 'Chats'
      # First authentication header
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      parameter name: :id, in: :path, type: :integer

      let!(:chat) { create :chat, name: 'test' }
      let!(:account_chat) { create :account_chat, account_id: account.id, chat_id: chat.id }

      let(:id) { chat.id }

      # Declare request parametes
      let(:observed_response_json) do
        {
          "data"=>
          {
            "id"=>chat.id.to_s,
            "type"=>"chat",
            "attributes"=>
            {
              "id"=>chat.id,
              "name"=>chat.name,
              "messages"=>[]
            },
              "relationships"=>
              {
                "accounts"=>
                {
                  "data"=>
                  [
                    {
                      "id"=>account.id.to_s,
                      "type"=>"account"
                    }
                  ]
                }
              }
            }
          }
      end

      # Create factories that you would need in this endpoint test
      response '200', :success do
        schema type: :object,
                properties: {
                  data: {
                    type: :array,
                    items: {
                      type: :object,
                      properties: {
                        id: { type: :string },
                        type: { type: :string },
                        attributes: {
                          type: :object,
                          properties:{
                            id: { type: :integer },
                            name: { type: :string },
                          }
                        },
                        relationships:{
                          type: :object,
                          properties:{
                            accounts:{
                              type: :object,
                              properties:{
                                data: {
                                  type: :array,
                                  items: {
                                    properties: {
                                      id: { type: :integer },
                                      type: { type: :string },
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }

        before do |example|
          submit_request(example.metadata)
        end

        it 'returns chat attributes' do
          expect(response.status).to eq 200
        end

        it 'Should return show of chat with same  response' do
          json_response = JSON.parse(response.body)
          expect(json_response).to eq(observed_response_json)
          expect(json_response["data"]["id"]).to eq chat.id.to_s
          expect(json_response["data"]["attributes"]["name"]).to eq chat.name
        end
      end

      response '400', :unauthorized do
        let(:token)  { '' }
        run_test!
      end
    end
  end

  path '/chat/chats/read_messages' do
    put 'Read a chat Messages' do
      tags 'Chats'
      # First authentication header
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      parameter name: :params1, in: :body, schema: {
        type: :object,
        properties: {
          chat_id: { type: :integer }
        }
      }

      let(:params1) {{
        chat_id: chat.id
      }}

      let(:chat_id) { chat.id }

      let!(:chat) { create :chat, name: 'test' }
      let!(:account_chat) { create :account_chat, account_id: account.id, chat_id: chat.id }
      let!(:message) { create :chat_message, message: 'This is a test message', chat: chat, is_mark_read: false }

      # Declare request parametes

      # Create factories that you would need in this endpoint test
      response '200', :success do
        schema type: :object,
                properties: {
                  message: { type: :string },
                }

        before do |example|
          submit_request(example.metadata)
        end

        # it 'Should return success message' do
        #   json_response = JSON.parse(response.body)
        #   expect(json_response["message"]).to eq("Message read successfully")
        # end

        it 'Should return read message to true' do
          json_response = JSON.parse(response.body)
          message.reload
          expect(message.is_mark_read).to eq(true)
        end
      end

      response '400', :unauthorized do
        let(:token)  { '' }
        run_test!
      end
    end
  end

  path '/chat/chats/history' do
    get 'Get chat history' do
      tags 'Chats'
      # First authentication header
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'

      parameter name: :receiver_id, in: :query, type: :integer

      let!(:chat) { create :chat, name: 'test' }
      let!(:account_chat) { create :account_chat, account_id: account.id, chat_id: chat.id }
      let(:receiver_account) { create :email_account }
      let!(:account_chat1) { create :account_chat, account_id: receiver_account.id, chat_id: chat.id }
      let!(:message) { create :chat_message, message: 'This is a test message', chat_id: chat.id, account: account }
      let(:receiver_id){ receiver_account.id }



      let(:observed_response_json) do
        {
          "data"=> [
            {
              "id"=> message.id.to_s,
              "type"=> "chat_message",
              "attributes"=>{
                "id"=> message.id,
                "message"=> message.message,
                "account_id"=> message.account_id,
                "chat_id"=> message.chat_id,
                "created_at"=> message.created_at.as_json,
                "updated_at"=> message.updated_at.as_json,
                "account"=> {
                  "id"=> account.id,
                  "first_name"=> account.first_name,
                  "last_name"=> account.last_name,
                  "full_phone_number"=> account.full_phone_number,
                  "country_code"=> account.country_code,
                  "phone_number"=> account.phone_number,
                  "email"=> nil,
                  "activated"=> account.activated,
                  "device_id"=> account.device_id,
                  "unique_auth_id"=> account.unique_auth_id,
                  "password_digest"=> account.password_digest,
                  "created_at"=>account.created_at.as_json,
                  "updated_at"=> account.updated_at.as_json,
                  "user_name"=> account.user_name
                }
              }
            }
          ]
        }
      end

      # Declare request parametes

      # Create factories that you would need in this endpoint test
      response '200', :success do
        schema type: :object,
                properties: {
                  receiver_id: { type: :integer },
                }

        before do |example|
          submit_request(example.metadata)
        end

        it 'Should return history of chat with status 200' do
          expect(response).to have_http_status(200)
        end

        it 'Should return history of chat with same json response' do
          json_response = JSON.parse(response.body)
          message1 = json_response["data"][0]["attributes"]["message"]
          expect(message1).to eq(observed_response_json["data"][0]["attributes"]["message"])
        end
      end

      response '400', :unauthorized do
        let(:token)  { '' }
        run_test!
      end
    end
  end

  path '/chat/chats/search_messages' do
    get 'Search a message record' do
      tags 'Chats'
      # First authentication header
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'

      # Declare request parametes
      parameter name: 'query', in: :query, schema: {
        type: :object,
        properties: {
          query:{
            type: :object,
            properties: {
              name: { type: :string }
            }
          }
        }
      }

      let(:query) { 'test'}

      let(:chat) { create :chat, name: 'This is a test chat', accounts: [account] }
      let(:account2) { create :email_account }
      let(:another_chat) { create :chat, name: 'Testing the chat', accounts: [account2] }

      let!(:matching_message) { create :chat_message, message: 'This is a test message', chat: chat }
      let!(:also_matching_message) { create :chat_message, message: 'Testing the message', chat: chat }
      let!(:not_matching_message) { create :chat_message, message: 'Message name', chat: chat }
      let!(:matching_from_another_chat) { create :chat_message, message: 'This is a test message', chat: another_chat }

      # Create factories that you would need in this endpoint test
      response '200', :success do
        schema type: :object,
                properties: {
                  data: {
                    type: :object,
                    properties: {
                      id: { type: :string },
                      type: { type: :string },
                      attributes: {
                        type: :object,
                        properties:{
                          id: { type: :integer },
                          name: { type: :string },
                        }
                      },
                      relationships:{
                        type: :object,
                        properties:{
                          accounts:{
                            type: :object,
                            properties:{
                              data: {
                                type: :array,
                                items: {
                                  properties: {
                                    id: { type: :integer },
                                    type: { type: :string },
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }

        before do |example|
          submit_request(example.metadata)
        end

        it 'returns matching chat messages' do |_|
          expect(response.status).to eq 200

          matched_ids = data.map { |chat| chat['id'].to_i }
          expect(matched_ids).to include(matching_message.id)
          expect(matched_ids).to include(also_matching_message.id)

          expect(matched_ids).not_to include(not_matching_message.id)
          expect(matched_ids).not_to include(matching_from_another_chat.id)
        end
      end

      response '400', :unauthorized do
        let(:token)  { '' }
        run_test!
      end
    end
  end


  path '/chat/chats/search' do
    get 'Search a chat group' do
      tags 'Chats'
      # First authentication header
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'

      # Declare request parametes
      parameter name: 'query', in: :query, schema: {
        type: :object,
        properties: {
          query:{
            type: :object,
            properties: {
              name: { type: :string }
            }
          }
        }
      }

      let(:query) { 'test' }

      let!(:matching_chat) { create :chat, name: 'This is a test chat', accounts: [account] }
      let!(:also_matching_chat) { create :chat, name: 'Testing the chat', accounts: [account] }
      let!(:not_matching_chat) { create :chat, name: 'Chat name', accounts: [account] }
      let(:account2) { create :email_account }
      let!(:matching_but_belongs_to_another_user) { create :chat, name: 'Testing the chat', accounts: [account2] }


      # Create factories that you would need in this endpoint test
      response '200', :success do
        schema type: :object,
                properties: {
                  data: {
                    type: :array,
                    items: {
                      id: { type: :string },
                      type: { type: :string },
                      attributes: {
                        type: :object,
                        properties:{
                          id: { type: :integer },
                          name: { type: :string },
                        }
                      },
                      relationships:{
                        type: :object,
                        properties:{
                          accounts:{
                            type: :object,
                            properties:{
                              data: {
                                type: :array,
                                items: {
                                  properties: {
                                    id: { type: :integer },
                                    type: { type: :string },
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }

        before do |example|
          submit_request(example.metadata)
        end

        it 'returns matching chats' do |_|
          expect(response.status).to eq 200
          matched_ids = data.map { |chat| chat['id'].to_i }
          expect(matched_ids).to include(matching_chat.id)
          expect(matched_ids).to include(also_matching_chat.id)

          expect(matched_ids).not_to include(not_matching_chat.id)
          expect(matched_ids).not_to include(matching_but_belongs_to_another_user.id)
        end
      end

      response '400', :unauthorized do
        let(:token)  { '' }
        run_test!
      end
    end
  end
end
