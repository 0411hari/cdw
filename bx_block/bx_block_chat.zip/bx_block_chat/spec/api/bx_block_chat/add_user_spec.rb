require 'rails_helper'
require 'pp'
require 'swagger_helper.rb'

RSpec.describe '/add_user', :jwt do

  let(:json) { JSON response.body }
  let(:jwt_token)  { jwt }

  let(:account) { create :email_account }
  let!(:chat) { create :chat, name: 'test' }
  let(:id) { account.id }

  describe 'POST /chat/chats/add_user' do
    let(:params) { { accounts_id: [account.id], chat_id: chat.id } }

    path '/chat/chats/add_user' do
      post 'Add users/accounts to chat' do
        tags 'AddUsers'
        consumes 'application/json'

        parameter name: :body, in: :body, schema: {
          type: :object,
          properties: {
            accounts_id: {
              type: :array,
              items: {
                type: :integer,
                example: [1,3]
              }
            },
            chat_id: { type: :integer }
          },
          required: [
            'accounts_id',
            'chat_id'
          ]
        }

        parameter name: :token, in: :header, type: :string, default: '{{bx_blocks_api_token}}'

        response '201', 'Add users/accounts to chat' do
          let(:body) { params }
          let(:token) { jwt_token }

          run_test!
        end
      end
    end
  end
end
