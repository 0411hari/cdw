require 'swagger_helper'

RSpec.describe '/chat', :jwt do
  let(:endpoint) { '/chat/chats' }

  let(:headers) { {:token => token} }

  let(:json) { JSON response.body }
  let(:data) { json['data'] }
  let(:token) { jwt }
  let(:jwt_token)  { jwt }
  let(:attributes) { data['attributes'] }
  let(:errors) { json['errors'] }
  let(:error) { errors.first }
  let(:model_errors) { data['attributes']['errors'] }
  let(:model_error) { errors.first }

  let(:account) { create :email_account }
  let(:account1) { create :email_account }
  let(:id) { account.id }
  let!(:chat) { create :chat, name: 'This is a test chat', accounts: [account, account1] }


  path '/chat/chats/{chat_id}/messages' do
    post 'Send a message' do
      tags 'ChatMessage'
      consumes 'multipart/form-data'

      # First authentication header
      parameter name: 'token', in: :header, type: :string, default: '{{bx_blocks_api_token}}'
      # Declare request parametes
      parameter name: 'chat_id', in: :path, type: :string, required: true

      parameter name: 'message[attachments]',
        description: 'attachment',
        in: :formData,
        attributes: {
          schema: {
            type: :object,
            properties: {
              attachments: { type: :binary },
            },
          },
        }

      parameter name: 'message[message]',
        description: 'message',
        in: :formData,
        attributes: {
          schema: {
            type: :object,
            properties: {
              message: { type: :string },
            },
          },
        }

      let(:chat_id) { chat.id }

      let(:"message[attachments]") {
        Rack::Test::UploadedFile.new(
          Rails.root.join('spec', 'fixtures', 'files', 'default_user.png'),
          'image/png'
        )
      }
      let(:"message[message]") { 'test message' }

      # Create factories that you would need in this endpoint test
      response '201', :success do

        schema type: :object,
                properties: {
                  data: {
                    type: :object,
                    properties: {
                      id: { type: :string },
                      type: { type: :string },
                      attributes: {
                        type: :object,
                        properties:{
                          id: { type: :integer },
                          message: { type: :string },
                          account_id: { type: :integer },
                          chat_id: { type: :integer },
                          created_at: { type: :string },
                          updated_at: { type: :string },
                          attachments: {
                            type: :array,
                            items: {
                              properties: {
                                id: { type: :integer },
                                url: { type: :string },
                              }
                            }
                          },
                        }
                      }
                    }
                  }
                }

        before do |example|
          submit_request(example.metadata)
        end

        it 'creates chat record' do |_|
          # Check response contents
          expect(response.status).to eq 201
          expect(BxBlockChat::Chat.count).to eq 1
          expect(BxBlockPushNotifications::PushNotification.count).to eq 1
        end
      end

      response '400', :unauthorized do
        let(:token)  { '' }
        run_test!
      end
    end
  end



end
