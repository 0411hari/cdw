require 'rails_helper'
require 'pp'
require 'swagger_helper.rb'

RSpec.describe '/leave', :jwt do

  let(:json) { JSON response.body }
  let(:jwt_token)  { jwt }

  let(:account) { create :email_account }
  let!(:chat) { create :chat, name: 'test' }
  let(:id) { account.id }

  describe 'POST /chat/chats/leave' do
    let(:params) { { chat_id: chat.id } }

    path '/chat/chats/leave' do
      post 'Leave chat' do
        tags 'LeaveChat'
        consumes 'application/json'

        parameter name: :body, in: :body, schema: {
          type: :object,
          properties: {
            chat_id: { type: :integer }
          },
          required: [
            'chat_id'
          ]
        }

        parameter name: :token, in: :header, type: :string, default: '{{bx_blocks_api_token}}'

        response '200', 'Leave chat' do
          let(:body) { params }
          let(:token) { jwt_token }

          run_test!
        end
      end
    end
  end
end
